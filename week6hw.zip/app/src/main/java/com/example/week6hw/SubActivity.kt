package com.example.week6hw

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*

class SubActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sub)

        title = "Week6ExampleL5"

        val iv : ImageView = findViewById(R.id.iv_sub)

        val korName : TextView = findViewById(R.id.tv_korName)
        val engName : TextView = findViewById(R.id.tv_engName)
        val contact : TextView = findViewById(R.id.tv_contact)
        val email : TextView = findViewById(R.id.tv_email)
        val address : TextView = findViewById(R.id.tv_address)

        iv.setImageBitmap(intent.getParcelableExtra("photo"))

        korName.text = intent.getStringExtra("korName")
        engName.text = intent.getStringExtra("engName")
        contact.text = intent.getStringExtra("contact")
        email.text = intent.getStringExtra("email")
        address.text = intent.getStringExtra("address")

        val ed1 : EditText = findViewById(R.id.ed1_sub)
        val ed2 : EditText = findViewById(R.id.ed2_sub)
        val ed3 : EditText = findViewById(R.id.ed3_sub)
        val ed4 : EditText = findViewById(R.id.ed4_sub)

        ed1.setText(intent.getStringExtra("Growth_Process"))
        ed2.setText(intent.getStringExtra("School_Days"))
        ed3.setText(intent.getStringExtra("Personality_S_W"))
        ed4.setText(intent.getStringExtra("Core_Competencies"))

        val btnSub : Button = findViewById(R.id.btn_sub)

        btnSub.setOnClickListener{
            intent.putExtra("Growth_Process", ed1.text.toString())
            intent.putExtra("School_Days", ed2.text.toString())
            intent.putExtra("Personality_S_W", ed3.text.toString())
            intent.putExtra("Core_Competencies", ed4.text.toString())
            setResult(Activity.RESULT_OK, intent)
            finish()
        }
    }
}