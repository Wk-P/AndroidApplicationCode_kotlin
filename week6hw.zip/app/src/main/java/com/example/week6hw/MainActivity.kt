package com.example.week6hw

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.drawable.toBitmap


class MainActivity : AppCompatActivity() {
    lateinit var iv : ImageView; lateinit var bm : Bitmap //사진과 intent로 전달할 bitmap

    lateinit var korName : EditText;  lateinit var engName : EditText;  lateinit var contact : EditText
    lateinit var email : EditText;  lateinit var address : EditText //한글/영어 이름, 연락처, 이메일, 주소

    //학력 칸
    lateinit var ed111: EditText; lateinit var ed112: EditText; lateinit var ed113: EditText; lateinit var ed114: EditText
    lateinit var ed121: EditText; lateinit var ed122: EditText; lateinit var ed123: EditText; lateinit var ed124: EditText
    lateinit var ed131: EditText; lateinit var ed132: EditText; lateinit var ed133: EditText; lateinit var ed134: EditText
    lateinit var ed141: EditText; lateinit var ed142: EditText; lateinit var ed143: EditText; lateinit var ed144: EditText

    //경력 칸
    lateinit var ed211: EditText; lateinit var ed212: EditText; lateinit var ed213: EditText
    lateinit var ed221: EditText; lateinit var ed222: EditText; lateinit var ed223: EditText
    lateinit var ed231: EditText; lateinit var ed232: EditText; lateinit var ed233: EditText
    lateinit var ed241: EditText; lateinit var ed242: EditText; lateinit var ed243: EditText

    //자격증 칸
    lateinit var ed311: EditText; lateinit var ed312: EditText; lateinit var ed313: EditText
    lateinit var ed321: EditText; lateinit var ed322: EditText; lateinit var ed323: EditText
    lateinit var ed331: EditText; lateinit var ed332: EditText; lateinit var ed333: EditText
    lateinit var ed341: EditText; lateinit var ed342: EditText; lateinit var ed343: EditText

    //자소서 정보
    var res1 = ""; var res2 = ""; var res3 = ""; var res4 = ""

    private val GALLERY = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        title = "Week6ExampleL5" //제목 설정

        iv = findViewById(R.id.image) //imageView 등록 및 클릭시 갤러리에서 이미지 불러오기
        iv.setOnClickListener{
            openGallery()
        }
        bm = iv.drawable.toBitmap() // 등록된 안드로이드 사진을 우선 bm에 저장해두어 사진 없이 intent로 넘길 때 오류 방지, 안드로이드 사진 그대로 넘겨줌

        korName = findViewById(R.id.krname); engName = findViewById(R.id.engname); contact = findViewById(R.id.number)
        email = findViewById(R.id.email); address = findViewById(R.id.address)

        //학력 EditText 등록
        ed111 = findViewById(R.id.ev111); ed112 = findViewById(R.id.ev112); ed113 = findViewById(R.id.ev113); ed114 = findViewById(R.id.ev114)
        ed121 = findViewById(R.id.ev121); ed122 = findViewById(R.id.ev122); ed123 = findViewById(R.id.ev123); ed124 = findViewById(R.id.ev124)
        ed131 = findViewById(R.id.ev131); ed132 = findViewById(R.id.ev132); ed133 = findViewById(R.id.ev133); ed134 = findViewById(R.id.ev134)
        ed141 = findViewById(R.id.ev141); ed142 = findViewById(R.id.ev142); ed143 = findViewById(R.id.ev143); ed144 = findViewById(R.id.ev144)

        //경력 EditText 등록
        ed211 = findViewById(R.id.ev211); ed212 = findViewById(R.id.ev212); ed213 = findViewById(R.id.ev213)
        ed221 = findViewById(R.id.ev221); ed222 = findViewById(R.id.ev222); ed223 = findViewById(R.id.ev223)
        ed231 = findViewById(R.id.ev231); ed232 = findViewById(R.id.ev232); ed233 = findViewById(R.id.ev233)
        ed241 = findViewById(R.id.ev241); ed242 = findViewById(R.id.ev242); ed243 = findViewById(R.id.ev243)

        //자격증 EditText 등록
        ed311 = findViewById(R.id.ev311); ed312 = findViewById(R.id.ev312); ed313 = findViewById(R.id.ev313)
        ed321 = findViewById(R.id.ev321); ed322 = findViewById(R.id.ev322); ed323 = findViewById(R.id.ev323)
        ed331 = findViewById(R.id.ev331); ed332 = findViewById(R.id.ev332); ed333 = findViewById(R.id.ev333)
        ed341 = findViewById(R.id.ev341); ed342 = findViewById(R.id.ev342); ed343 = findViewById(R.id.ev343)

        intent = Intent(this, SubActivity::class.java) //자소서 칸으로 넘겨줄 Intent 생성

        val btnMain : Button = findViewById(R.id.btn_main) //자소서 버튼 등록 및 구현
        btnMain.setOnClickListener{

            intent.putExtra("photo", bm) // 사진 전달

            //한글/영어 이름, 연락처, 이메일, 주소 edittext의 정보 입력
            intent.putExtra("korName", korName.text.toString()); intent.putExtra("engName", engName.text.toString())
            intent.putExtra("contact", contact.text.toString()); intent.putExtra("email", email.text.toString())
            intent.putExtra("address", address.text.toString())

            // SubActivity의 정보를 양방향 이동간에서 저장하기 위하여 res를 이용하여 저장하고 전달
            intent.putExtra("Growth_Process", res1); intent.putExtra("School_Days", res2)
            intent.putExtra("Personality_S_W", res3); intent.putExtra("Core_Competencies", res4)

            startActivityForResult(intent, 100)
        }
    }

    private fun openGallery(){
        val it = Intent(Intent.ACTION_GET_CONTENT) //갤러리 호출을 위한 별도의 intent 생성,
        it.type = "image/*" //image 타입을 검색
        startActivityForResult(it, GALLERY) //gallery 호출 후 결과값 확인하여 추가 작업
    }

    fun resizeBitmap(bitmap: Bitmap, width:Int, height:Int):Bitmap{
        return Bitmap.createScaledBitmap(
            bitmap, width, height, true
        )
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if(resultCode == Activity.RESULT_OK){ //무사히 종료된 경우
            when(requestCode){ //requestcode에 따라 작업 분류
                1 -> { //1은 갤러리 호출
                    try{ //이미지를 가져와서 비트맵으로 변환 시도
                        val imageData : Uri? = data?.data //Intent data의 경로
                        bm = MediaStore.Images.Media.getBitmap(contentResolver,imageData) //경로의 사진을 bitmap으로 가져옴
                        bm = resizeBitmap(bm, 300, 300)
                        iv.setImageBitmap(bm) // imageview에 이미지 출력
                    }catch(e:Exception){
                        e.printStackTrace()
                    }
                }
                100 -> { //자기소개서의 값이 SubActivity가 종료된 후에도 남아있어야 하므로 종료될때 mainactivity로 전달
                    res1 = data?.getStringExtra("Growth_Process").toString()
                    res2 = data?.getStringExtra("School_Days").toString()
                    res3 = data?.getStringExtra("Personality_S_W").toString()
                    res4 = data?.getStringExtra("Core_Competencies").toString()
                }
            }
        }
    }
}