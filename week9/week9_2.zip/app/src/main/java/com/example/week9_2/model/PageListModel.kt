package com.example.week9_2.model

class PageListModel {
    var articles: MutableList<ItemModel>? = null
}

